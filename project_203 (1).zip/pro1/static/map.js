function fetchDataAndUpdateCharts() {
    fetch('/get-datacharts')
        .then(response => response.json())
        .then(data => {
          console.log(data);
          updateDataCharts(data); // Corrected function name
        })
        .catch(error => console.error('Error:', error));
}

function updateDataCharts(data) {
    console.log(data);
    am5.ready(function() {
        // Create root element
        var root = am5.Root.new("mapdiv");

        root.setThemes([
            am5themes_Animated.new(root)
        ]);

        var chart = root.container.children.push(am5percent.PieChart.new(root, {
            layout: root.verticalLayout,
            innerRadius: am5.percent(50)
        }));

        var series = chart.series.push(am5percent.PieSeries.new(root, {
            valueField: "value",
            categoryField: "class",
            alignLabels: false
        }));

        series.labels.template.setAll({
            textType: "circular",
            centerX: 0,
            centerY: 0
        });

        // Set data
        series.data.setAll(data); // Use the provided data

        // Create legend
        var legend = chart.children.push(am5.Legend.new(root, {
            centerX: am5.percent(50),
            x: am5.percent(50),
            marginTop: 15,
            marginBottom: 15,
        }));

        legend.data.setAll(data);

        // Play initial series animation
        series.appear(1000, 100);
    });
}

document.addEventListener('DOMContentLoaded', function() {
    fetchDataAndUpdateCharts(); // Corrected function name
});