from flask import Flask, jsonify, render_template
import pandas as pd
from sqlalchemy import create_engine
import sqlite3

def create_connection(db_file):
    """ create a database connection to a SQLite database """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)
    return conn

df = pd.read_csv("Doctor_data.csv")
connection = create_connection("demo.db")
df.to_sql('heart_data',connection,if_exists='replace')
connection.close();
db_url = 'sqlite:///demo.db'
engine= create_engine(db_url,echo=True)
df_2= pd.read_sql('select * from heart_data',engine)



df2 = pd.read_csv("Grades_data.csv")
df3 = pd.read_csv("Student_data.csv")

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/get-datachart")
def get_datachart():
    classes = df3["Faculty_Name"].value_counts().index
    values = df3["Faculty_Name"].value_counts().values

    data = []

    for i in range(len(classes)):
        data.append({"class": classes[i], "value": int(values[i])})

    return jsonify(data)
@app.route("/get-datatable")
def get_datatable():
    classes = df3["Major"].value_counts().index
    values = df3["Major"].value_counts().values

    datab = []

    for i in range(len(classes)):
        datab.append({"class": classes[i], "value": int(values[i])})

    return jsonify(datab)
@app.route("/get-datacharts")
def get_datacharts():
    classes = df2["Grade_letter"].value_counts().index
    values = df2["Grade_letter"].value_counts().values

    datan = []

    for i in range(len(classes)):
        datan.append({"class": classes[i], "value": int(values[i])})

    return jsonify(datan)
@app.route("/get-datacurved")
def get_datacurved():
    classes = df3["favourite_doctor"].value_counts().index
    values = df3["favourite_doctor"].value_counts().values

    datag = []

    for i in range(len(classes)):
        datag.append({"class": classes[i], "value": int(values[i])})

    return jsonify(datag)

if __name__ == "__main__":
    app.run(debug=True)


